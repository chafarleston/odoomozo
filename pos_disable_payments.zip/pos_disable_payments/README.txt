

Version 12.0.0.2:
		- Solve the issue of edit table in bar.
		
=> 09-04-2019 - 12.0.0.3 : Create index according to new format , Improve manifest file.

Version 12.0.0.4: (24/01/20)
		- Solve the issue of disable payment when customer change.